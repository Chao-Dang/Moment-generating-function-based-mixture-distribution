function dy = Bouc_Wen(t,y,EL,m,c,k,alpha,A,beta,gama,n,storey)

%BOUC_WEN �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��


% global z;
% if t/0.01==0
%     z=0;
% else
%    z=(y(2)*y(3)+z);
% end
%    z


f=-m*ones(storey,1).*EL(round(t/0.02)+1);

v1=y(1:storey);             %y(2)
v2=y(storey+1:2*storey);    %y(2)
v3=y(2*storey+1:3*storey);    %y(3)


dy(1:storey,:)=v2;
dy(storey+1:2*storey,:)=inv(m)*(f-c*v2-alpha*k*v1-(1-alpha)*k*v3);
%  dy(2*storey+1:3*storey,:)=v2.*(A-(beta*sign(v3.*v2)+gama).*abs(v3).^(n));
 dy(2*storey+1:3*storey,:)=A.*v2-beta.*abs(v2).*((abs(v3)).^(n-1)).*v3-gama.*v2.*((abs(v3)).^n);

    



end


% dy=[y(2);
%     inv(m)*(f-c*y(2)-alpha*k*y(1)-(1-alpha)*k*y(3));
%     y(2)*(A-(beta*sign(y(3)*y(2))+gama)*abs(y(3))^(n));
% ];

