% This code aims to abtian the extrme value of a nonliear shear frame
% structure under fully non-stationary stochastic seismic ground motions
% based on MCS


clear all; close all; clc

tic 
num = 1e6;

[ wgn ] = Fully_non_stationary_stochastic_ground_motions( num );


[ D1,D2,D3,D4,D5,D6,D7,D8,D9,D10 ] = Nonlinear_shear_frame_structure( wgn,num );
toc


