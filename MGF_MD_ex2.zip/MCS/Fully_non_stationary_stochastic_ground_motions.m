function [ x ] = Fully_non_stationary_stochastic_ground_motions( num )
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

wg = 5*pi;
sg = 0.60;
wf = 0.5*pi;
sf = 0.60;


amax = 196.2;
gama = 2.65;
s_ = amax^2/((gama^2)*(pi*wg*(2*sg+1/(2*sg))));            %��ǿ������


N = 1600; 
i = 1:N;
wu = 240;                  %ԲƵ������ֵ
dw = 0.15;
wl=wu-N*dw;                         %ԲƵ������ֵ
% dw=(wu-wl)./N;
w=wl+i.*dw;                   %Ƶ�ʻ���



sw = (wg.^4+(2.*sg.*wg.*w).^2).*(w.^4).*s_./(((w.^2-wg.^2).^2+(2.*sg.*wg.*w).^2).*((w.^2-wf.^2).^2+(2.*sf.*wf.*w).^2));

% figure(1)
% plot(w,sw);


T = 30;
TT= 1501;
dt = 0.02;
t = 0:dt:T;
c = 9.0;
d = 2.0;
gt = ((t./c).*(exp(1-t./c))).^d;


wa = wg;
ta = T;
eta = 0.15;
for m = 1:length(t)     %ʱ��ѭ��
    for n = 1:length(w)  %Ƶ��ѭ��
        Atw(m,n)= exp(-eta.*w(n).*t(m)./(wa*ta)).*gt(m);
        SX(m,n)= (Atw(m,n)^2)*sw(n);
    end
end


% fai = unifrnd(0,2*pi,[num,N]);

x = zeros(TT,num);
for j = 1:num
    j
    fai1 = normrnd(0,1,[1,N/2]);
    fai2 = normrnd(0,1,[1,N/2]);

    for i = 1:N/2
        
%         x(:,j) = x(:,j)+sqrt(2.*SX(:,i).*dw).*(cos(w(i).*t'+fai(i)));
                
        x(:,j) = x(:,j) + sqrt(2.*SX(:,i).*dw).*( fai1(i).*cos(w(i).*t') +  fai2(i).*sin(w(i).*t') ) ;
    end
end

end

