clear all;close all;clc

%% LPSS
N = 1620;          % total number of random variables
num  = 25^2;
lpss_design = 2*ones(N/2,1);
lpss_strata = sqrt(num)*ones(N/2,1);
[x_lpss] = LPSS(lpss_design,lpss_strata);

%stochastic seismic ground motions
 Fai = x_lpss(:,1:1600);
 [ x ] = Fully_non_stationary_stochastic_ground_motions_lpss( num,Fai );

% dynamic response analysis of the bouc-wen structure
 MK = x_lpss(:,1601:N);
 [ L1,L2,L3,L4,L5,L6,L7,L8,L9,L10 ] = Nonlinear_shear_frame_structure_lpss( x,num,MK );



% figure(1)
%  plot(0:0.02:30,wgn(:,1))
%  xlabel('$\rm Time, (s)$','interpreter','latex','FontSize',12)
% ylabel('$\rm Acceleration, (cm/s^2)$','interpreter','latex','FontSize',12)
% set(gca,'FontSize',12);
% set(gca,'FontName','Timesnewroman');
% 
% figure(2)
%  plot(0:0.02:30,wgn(:,2))
%  xlabel('$\rm Time, (s)$','interpreter','latex','FontSize',12)
% ylabel('$\rm Acceleration, (cm/s^2)$','interpreter','latex','FontSize',12)
% set(gca,'FontSize',12);
% set(gca,'FontName','Timesnewroman');
% 
% figure(3)
%  plot(0:0.02:30,wgn(:,4))
%  xlabel('$\rm Time, (s)$','interpreter','latex','FontSize',12)
% ylabel('$\rm Acceleration, (cm/s^2)$','interpreter','latex','FontSize',12)
% set(gca,'FontSize',12);
% set(gca,'FontName','Timesnewroman');

% mu = mean(x,2);
% st = std(x,0,2);
% st_t = sqrt(sum(SX,2).*dw);


% figure(3)
% plot(t,zeros(1,length(t)),'r-','LineWidth',1.5);
% hold on
% plot(t,mu,'b--','LineWidth',1.5);
% h=legend('Target','Simulated');
% set(h,'Interpreter','latex','FontSize',12)
% xlabel('$\rm Time, (s)$','interpreter','latex','FontSize',12)
% ylabel('$\rm Mean, (cm/s^2)$','interpreter','latex','FontSize',12)
% set(gca,'FontSize',12);
% set(gca,'FontName','Timesnewroman');
% % ylim([-50 50])
% hold off
% 
% 
% 
% figure(4)
% plot(t,sqrt(2).*st_t,'r-','LineWidth',1.5);
% hold on
% plot(t,st,'b--','LineWidth',1.5);
% h=legend('Target','Simulated');
% set(h,'Interpreter','latex','FontSize',12)
% xlabel('$\rm Time, (s)$','interpreter','latex','FontSize',12)
% ylabel('$\rm Std.D, (cm/s^2)$','interpreter','latex','FontSize',12)
% set(gca,'FontSize',12);
% set(gca,'FontName','Timesnewroman');



%%
G = D1';  % MCS result
GX = L1;

mu = mean(GX);
st = std(GX);
gmin = 0.1;
gmax = mu + 20*st;
g = gmin:(gmax-gmin)./1000:gmax;
weights = ones(1,num)./num;



% 95% confidence interval
mgf = @(t,Z) mean(exp(t.*Z));
mgf_confiinterval = @(t,Z) [mean(exp(t.*Z)) - 1.96.*std(exp(t.*Z))./sqrt(num);mean(exp(t.*Z)) + 1.96.*std(exp(t.*Z))./sqrt(num)];

alpha = -0.8:0.01:0;

MGF_ref = mgf(alpha,G);
MGF_est = mgf(alpha,GX);
MGF_conint_est = mgf_confiinterval(alpha,GX);

figure(1)
plot(alpha,MGF_ref,'r-','LineWidth',1.0)
hold on 
plot(alpha,MGF_est,'b--','LineWidth',1.0)
plot(alpha,MGF_conint_est,'g-.','LineWidth',1.0)
h=legend('MCS','LPSS','95\% confidence interval');
set(h,'Interpreter','latex','FontSize',12)
xlabel('$ \tau~\rm $','interpreter','latex','FontSize',12)
ylabel('$\rm Moment-generating~function$','interpreter','latex','FontSize',12)
set(gca,'FontSize',12);
set(gca,'FontName','Timesnewroman');




Num_mcs = 1e6;




k = [0.1,0.2,0.3,0.4,0.5,0.6,0.7].*1;



[ xx ,Pdf,Cdf ] = mixture_of_two_generalized_inverse_gaussian( k,weights,GX',g );

PDF1 = xx(1).*gigpdf(g,xx(2),xx(3),xx(4));
PDF2 = (1-xx(1)).*gigpdf(g,xx(5),xx(6),xx(7));




figure(2)
[j,i]=hist(G,60);
j=j/length(G)/mean(diff(i));
b=bar(i,j,1,'g');
hold on;
plot(g,Pdf,'b-','LineWidth',2)
plot(g,PDF1,'r--','LineWidth',2)
plot(g,PDF2,'r--','LineWidth',2)
% xlim([0 100])
h=legend('MCS','Proposed method','Mixture components');
set(h,'Interpreter','latex','FontSize',12)
xlabel('$ z,\rm (mm)$','interpreter','latex','FontSize',12)
ylabel('$\rm PDF$','interpreter','latex','FontSize',12)
set(gca,'FontSize',12);
set(gca,'FontName','Timesnewroman');


figure(3)
gg = min(G):0.01:max(G);
h_mcs = hist(G,gg);
cdf_mcs = cumsum(h_mcs)/sum(h_mcs);
semilogy(gg,cdf_mcs,'g-','LineWidth',2)
hold on
semilogy(g,Cdf,'b--','LineWidth',2)
ylim([1e-10 1])
h=legend('MCS','Proposed method');
set(h,'Interpreter','latex','FontSize',12)
xlabel('$ z,\rm (mm)$','interpreter','latex','FontSize',12)
ylabel('$\rm CDF~(log~scale)$','interpreter','latex','FontSize',12)
set(gca,'FontSize',12);
set(gca,'FontName','Timesnewroman');

figure(4)
gg = min(G):0.01:max(G);
h_mcs = hist(G,gg);
cdf_mcs = cumsum(h_mcs)/sum(h_mcs);
semilogy(gg,1-cdf_mcs,'g-','LineWidth',2)
hold on
semilogy(g,1-Cdf,'b--','LineWidth',2)
ylim([1e-10 1])
h=legend('MCS','Proposed method');
set(h,'Interpreter','latex','FontSize',12)
xlabel('$ z,\rm (mm)$','interpreter','latex','FontSize',12)
ylabel('$\rm POE~(log~scale)$','interpreter','latex','FontSize',12)
set(gca,'FontSize',12);
set(gca,'FontName','Timesnewroman');


%% comparsion of the first-passage failure probabilities
 
threshold = 72:8:120;

for i = 1:length(threshold)
   pf(1,i) = sum(G>threshold(i))./Num_mcs;
   pf(2,i) = interp1(g,1-Cdf,threshold(i));
end
