function [ xx ,Pdf,Cdf ] = mixture_of_two_generalized_inverse_gaussian(  k,weights,GX,g )
%MIXTURE_OF_TWO_GENERALIZED_INVERSE_GAUSSIAN �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

mu = weights*GX;
va = weights*GX.^2-mu.^2;

para1 = mu;          
para2 = mu^3/va;

a = para2./para1.^2;
b = para2;
p = -1/2;

x0 = [0.40,a,b,p,a,b,p];

fun = @(x)[ analytical_raw_moments(x,k(1))-estimated_raw_moments(weights,GX,k(1));
    analytical_raw_moments(x,k(2))-estimated_raw_moments(weights,GX,k(2));
    analytical_raw_moments(x,k(3))-estimated_raw_moments(weights,GX,k(3));
    analytical_raw_moments(x,k(4))-estimated_raw_moments(weights,GX,k(4));
    analytical_raw_moments(x,k(5))-estimated_raw_moments(weights,GX,k(5));
    analytical_raw_moments(x,k(6))-estimated_raw_moments(weights,GX,k(6));
    analytical_raw_moments(x,k(7))-estimated_raw_moments(weights,GX,k(7));    
];
AlGO = {'trust-region-dogleg','trust-region','levenberg-marquardt','trust-region-reflective'};

opts = optimoptions('fsolve','Algorithm',AlGO{1},'MaxFunctionEvaluations',5e3,'FunctionTolerance',1e-100,'StepTolerance',1e-100,'MaxIterations',5e3,'Display','iter','OptimalityTolerance',1e-8);
xx = fsolve(fun,x0,opts);

% options  = optimoptions('lsqnonlin','Display','iter','Algorithm',AlGO{4},'MaxFunctionEvaluations',1e4,'FunctionTolerance',1e-100,'StepTolerance',1e-100,'MaxIterations',1e4,'OptimalityTolerance',1e-16);
% xx = lsqnonlin(fun,x0,[0.1,0,0,-inf,0,0,-inf],[1-0.1,inf,inf,inf,inf,inf,inf],options);


Pdf = xx(1).*gigpdf(g,xx(2),xx(3),xx(4))+ (1-xx(1)).*gigpdf(g,xx(5),xx(6),xx(7));
Cdf = cumsum(Pdf)./sum(Pdf);




end


function [raw_a] = analytical_raw_moments(x,k)

raw_a = x(1)*(x(2)./(x(2)+2.*k)).^(x(4)/2).*besselk(x(4),sqrt(x(3)*(x(2)+2*k)))./besselk(x(4),sqrt(x(3)*x(2))) + (1-x(1))*(x(5)./(x(5)+2.*k)).^(x(7)/2).*besselk(x(7),sqrt(x(6)*(x(5)+2*k)))./besselk(x(7),sqrt(x(6)*x(5)));



end





function [raw_e] = estimated_raw_moments(weights,GX,k)

raw_e = weights*exp(-k*GX);



end

function [ f ] = gigpdf(x,a,b,p)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

f = (a/b).^(p/2).*x.^(p-1).*exp(-(a.*x+b./x)./2)./(2.*besselk(p,sqrt(a*b)));

end