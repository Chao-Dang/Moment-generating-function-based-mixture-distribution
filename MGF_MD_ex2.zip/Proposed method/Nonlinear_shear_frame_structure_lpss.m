function [ D1,D2,D3,D4,D5,D6,D7,D8,D9,D10 ] = Nonlinear_shear_frame_structure_lpss( x,num,MK )
%NONLIEAR_SHEAR_FRAME_STRUCTURE_LPSS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

%%
storey = 10;
% alpha=0.02;
% A=1;
% beta=50;
% gama=20;
% n=1;
u = 0.01;
alpha = 0.20;
A = 1;
n = 3;
beta = 1./(2*u^n);
gama = 1./(2*u^n);

x0=zeros(3*storey,1);
m=[3.0	2.95 2.90  2.85  2.80 2.75  2.70  2.65  2.60  2.55]'.*2e5;
k=[2.5  2.45  2.4  2.35  2.3  2.25 2.2  2.15 2.1  2.05]'.*1e7;
%k=[3.5  3.45  3.4  3.35  3.3  3.25 3.2  3.15 3.1  3.05]'.*1e7;



cov_m(1:storey,1) = 0.10;
cov_k(1:storey,1) = 0.15;

[m_mu,m_sig] = lognormal_permaters(m,cov_m);




for  iii=1:num
    
%  for aa=1:storey
%     mm(aa)=lognrnd(m_mu(aa),m_sig(aa),[1,1]);
%     kk(aa)=normrnd(k(aa),cov_k(aa)*k(aa),[1,1]);
% end

 for aa=1:storey
    mm(aa) = logninv(MK(iii,aa),m_mu(aa),m_sig(aa));
    kk(aa)= norminv(MK(iii,aa+storey),k(aa),cov_k(aa)*k(aa));
end


%�γ���������
mass=diag(mm);


%�γɸնȾ���
stiffness=zeros(storey,storey);
for i=1:storey-1
    stiffness(i,i)=kk(i)+kk(i+1);
    stiffness(i,i+1)=-kk(i+1);
    stiffness(i+1,i)=-kk(i+1);
end
stiffness(storey,storey)=kk(storey);

%���ṹ��������
[xx,d]=eig(stiffness,mass);
d=diag(sqrt(d));
for i=1:storey
    [d1(i),j]=min(d);
    xgd(:,i)=xx(:,j);
    d(j)=max(d)+1;
end
w=d1;
xx=xgd;
%�������ϵ��
a1=2*w(1)*w(2)*(0.05*w(2)-0.05*w(1))/(w(2)^2-w(1)^2);
a2=2*(0.05*w(2)-0.05*w(1))/(w(2)^2-w(1)^2);

%�γ��������
damp=a1.*mass+a2.*stiffness;

    
    
    EL=0.01*x(:,iii);
    
    [t,yy]=ode45(@Bouc_Wen,[0:0.02:30],x0,[],EL,mass,damp,stiffness,alpha,A,beta,gama,n,storey);
%     D1(iii)=1000*max(abs(yy(:,1)));
%     D2(iii)=1000*max(abs(yy(:,4)-yy(:,1)));
%     D3(iii)=1000*max(abs(yy(:,7)-yy(:,4)));
%     D4(iii)=1000*max(abs(yy(:,10)-yy(:,7)));
%     D5(iii)=1000*max(abs(yy(:,13)-yy(:,7)));
%     D6(iii)=1000*max(abs(yy(:,16)-yy(:,13)));
    

    D1(iii)=1000*max(abs(yy(:,1)));
    D2(iii)=1000*max(abs(yy(:,2)-yy(:,1)));
    D3(iii)=1000*max(abs(yy(:,3)-yy(:,2)));
    D4(iii)=1000*max(abs(yy(:,4)-yy(:,3)));
    D5(iii)=1000*max(abs(yy(:,5)-yy(:,4)));
    D6(iii)=1000*max(abs(yy(:,6)-yy(:,5)));
    D7(iii)=1000*max(abs(yy(:,7)-yy(:,6)));
    D8(iii)=1000*max(abs(yy(:,8)-yy(:,7)));
    D9(iii)=1000*max(abs(yy(:,9)-yy(:,8)));
    D10(iii)=1000*max(abs(yy(:,10)-yy(:,9)));


    iii
    
end

k1=stiffness(1,1);

F=alpha*k1*yy(:,1)+(1-alpha)*k1*yy(:,2*storey+1);
figure(1);
plot(yy(:,1),F)
xlabel('$\rm Inter-story~drift, (m)$','interpreter','latex','FontSize',12)
ylabel('$\rm Restoring~force, (N)$','interpreter','latex','FontSize',12)
set(gca,'FontSize',12);
set(gca,'FontName','Timesnewroman');


end

